from setuptools import setup

setup(
    name="segunda_preentrega_cisneros",
    version="1.0",
    description="Programa de gestion de clientes",
    author="Julio Cisneros Rosales",
    author_email="juliocesarcisnerosrosales@gmail.com",
    
    packages=["segunda_preentrega_cisneros"],
)